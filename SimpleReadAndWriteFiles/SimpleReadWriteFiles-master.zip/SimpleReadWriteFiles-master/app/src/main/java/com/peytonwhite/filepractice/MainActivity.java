package com.peytonwhite.filepractice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.buttonWrite).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                writeData();

            }
        });

        findViewById(R.id.buttonRead).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<Integer> data = readData();
                displayData(data);
            }
        });


    }

    private ArrayList<Integer> readData(){

        ArrayList<Integer> data = new ArrayList<>();

        try {
            FileInputStream fis = openFileInput("numbers.txt");
            Scanner scanner = new Scanner(fis);
            
            while(scanner.hasNextInt())
            {
                int val = scanner.nextInt();
                data.add(val);
            }
            scanner.close();

        } catch (FileNotFoundException e) {


        }


        return data;

    }
    private void displayData(ArrayList<Integer> data){

        TextView tv = findViewById(R.id.textViewread);

        if(data.isEmpty())
        {
            tv.setText("data is empty");
        } else {
            tv.setText("");
            for(int val : data)
            {
                tv.append(val + "\n");
            }
        }

    }




    private void writeData(){


        try {
            FileOutputStream fos = openFileOutput("numbers.txt", Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            BufferedWriter bw = new BufferedWriter(osw);
            PrintWriter pw = new PrintWriter(bw);


            for(int i = 0; i <= 10;i++)
            {
                pw.println(i);

            }


            pw.close();
            Toast.makeText(getApplicationContext(),"data is saved into file",
                            Toast.LENGTH_SHORT).show();

        } catch (FileNotFoundException e) {
            //user doest see this
            Log.e("WRITE","can not open numbers.txt");
            Toast.makeText(getApplicationContext(),"error in opening file",
                            Toast.LENGTH_LONG).show();
            e.printStackTrace();

        }


    }


}
