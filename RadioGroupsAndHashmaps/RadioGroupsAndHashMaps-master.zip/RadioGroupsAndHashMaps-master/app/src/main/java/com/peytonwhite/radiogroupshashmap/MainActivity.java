package com.peytonwhite.radiogroupshashmap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener{

    private HashMap<Integer,Integer> backgroundColors;
    private HashMap<Integer,Integer> textColors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioGroup rg = findViewById(R.id.radioGroupBackgroundColor);
        rg.setOnCheckedChangeListener(this);

        RadioGroup rgTextColor = findViewById(R.id.radioGroupTextColor);
        rgTextColor.setOnCheckedChangeListener(this);



        backgroundColors = new HashMap<>();
        backgroundColors.put(R.id.radioButtonBlack,Color.BLACK);
        backgroundColors.put(R.id.radioButtonWhite,Color.WHITE);
        backgroundColors.put(R.id.radioButtonBlue,Color.BLUE);
        backgroundColors.put(R.id.radioButtonGreen,Color.GREEN);
        backgroundColors.put(R.id.radioButtonRed,Color.RED);
        backgroundColors.put(R.id.radioButtonCyan,Color.CYAN);

        textColors = new HashMap<>();
        textColors.put(R.id.radioButtonBlack,Color.BLACK);
        textColors.put(R.id.radioButtonWhite,Color.WHITE);
        textColors.put(R.id.radioButtonBlue,Color.BLUE);








    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int clickedId) {

        ConstraintLayout cl = findViewById(R.id.cl);
        TextView tv = findViewById(R.id.textViewColors);

        if(radioGroup.getId() == R.id.radioGroupBackgroundColor) {

            if (backgroundColors.containsKey(clickedId)) {
                int color = backgroundColors.get(clickedId);
                cl.setBackgroundColor(color);

            } else {
                throw new RuntimeException("illegal background color");
            }
        }
        else if(radioGroup.getId() == R.id.radioGroupTextColor)
        {
            if(textColors.containsKey(clickedId))
            {
                int color = textColors.get(clickedId);
                tv.setTextColor(color);
            }
            else
            {
                throw new RuntimeException("Illegal Text color");
            }
        }
        else
        {
            throw new RuntimeException("Illegal radiogroup");
        }






        /*
        if(clickedId == R.id.radioButtonBlack)
        {
            cl.setBackgroundColor(Color.BLACK);
        }
        else if(clickedId == R.id.radioButtonBlue)
        {
            cl.setBackgroundColor(Color.BLUE);
        }
        else if(clickedId == R.id.radioButtonCyan)
        {
            cl.setBackgroundColor(Color.CYAN);
        }
        else if(clickedId == R.id.radioButtonGreen)
        {
            cl.setBackgroundColor(Color.GREEN);
        }
        else if(clickedId == R.id.radioButtonWhite)
        {
            cl.setBackgroundColor(Color.WHITE);
        }
        else if(clickedId == R.id.radioButtonRed)
        {
            cl.setBackgroundColor(Color.RED);
        }


         */

    }
}
