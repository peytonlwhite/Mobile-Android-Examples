package edu.apsu.csci.recyclerviewexample_3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Integer> data;
    private Random rand;
    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rand = new Random();

        data = new ArrayList<>();
        data.add(10);
        data.add(20);
        data.add(42);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new MyAdapter(data);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_item_add) {
            addRandomNumber();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void addRandomNumber() {
        int val = rand.nextInt(100);
        data.add(val);
        adapter.notifyDataSetChanged();

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.scrollToPosition(data.size() - 1);
    }
}

interface RecyclerViewOnCLickListener {
    public void onClick(View view, int position);
}

class MyViewHolder extends RecyclerView.ViewHolder
        implements View.OnClickListener {

    private TextView view;
    private RecyclerViewOnCLickListener listener;

    public MyViewHolder(TextView view, RecyclerViewOnCLickListener listener) {
        super(view);
        this.view = view;
        this.listener = listener;
        this.view.setOnClickListener(this);
    }

    public TextView getView() {
        return view;
    }

    @Override
    public void onClick(View view) {
        listener.onClick(view, getAdapterPosition());
    }
}

class MyAdapter extends RecyclerView.Adapter<MyViewHolder>
        implements RecyclerViewOnCLickListener {
    private ArrayList<Integer> dataSet;

    public MyAdapter(ArrayList<Integer> dataSet) {
        this.dataSet = dataSet;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView view = (TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_view, parent, false);
        MyViewHolder viewHolder = new MyViewHolder(view, this);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TextView view = holder.getView();
        view.setText(Integer.toString(dataSet.get(position)));
        Log.i("STATE", "added " + dataSet.get(position));
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    @Override
    public void onClick(View view, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setMessage("You clicked on " + dataSet.get(position));
        builder.setPositiveButton("Close", null);
        builder.show();
    }
}
